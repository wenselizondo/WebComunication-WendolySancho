'use extrict';

window.addEventListener('load', init, false);

function init() {
    let nombre = document.getElementById('nombreTxt');
    let email = document.getElementById('emailTxt');
    let numero = document.getElementById('numberTxt');
    let mensaje = document.getElementById('mensajeTxt');
    let alerta = document.getElementById('mensajeAlert');
    let btnEnviar = document.getElementById('btnSend');
    let expressionEmail = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;


    btnEnviar.onclick = function() {
        nombre = nombreTxt.value;
        email = emailTxt.value;
        numero = numberTxt.value;
        mensaje = mensajeTxt.value;

        if (nombre === '' && email === '' && numero === '' && mensaje === '') {
            alerta.textContent = 'Recuerda llenar todos los campos.';
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '¡No tan rápido!',
                footer: 'Bríndanos tu información primero.'
            });
        } else if (nombre === '') {
            alerta.textContent = 'El campo nombre esta vacío';
        } else if (email === '') {
            alerta.textContent = 'El campo email esta vacío';
        } else if (expressionEmail.test(email) === false) {
            alerta.textContent = 'Email invalido';
        } else if (numero === '') {
            alerta.textContent = 'El campo teléfono esta vacío';
        } else if (mensaje === '') {
            alerta.textContent = 'El campo mensaje esta vacío';
        } else {
            alerta.textContent = 'Recibimos tu info';
            Swal.fire(
                'Listo!',
                'Te contactaremos',
                'success'
            );            
            alerta.classList.add('alertaVerde');
            alerta.classList.remove('alertaRoja');
            emailjs.sendForm('service_3dm66z1', 'template_p8tnspr', '#formTest', '_uD5IuNGshSl8NYGX');4
            
        }
    }

    function cleanInputs() {
        nombreTxt.value = '';
        emailTxt.value = '';
        numberTxt.value = '';
        mensajeTxt.value = '';
    }
}